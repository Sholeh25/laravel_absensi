<?php

use App\Attendance;
use App\Department;
use \DateTime as DateTime;
use App\User;
use App\Employee;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // PERBAIKAN 1: Urutan Truncate diubah agar aman (anak dulu, baru induk)
        DB::table('attendances')->truncate();
        DB::table('employees')->truncate();
        DB::table('role_user')->truncate();
        DB::table('users')->truncate();
        DB::table('departments')->truncate();

        // PERBAIKAN 2: Pindahkan blok Departemen ke atas
        // Data Departemen DIBUAT DULUAN
        Department::create(['name' => 'Manajemen']); // id 1
        Department::create(['name' => 'Perawat']); // id 2
        Department::create(['name' => 'Bidan']); // id 3
        Department::create(['name' => 'Dokter']); // id 4
        Department::create(['name' => 'Kasir']); // id 5
        Department::create(['name' => 'Farmasi']); // id 6
        Department::create(['name' => 'Front Office']); // id 7
        Department::create(['name' => 'Petugas Kebersihan']); // id 8
        Department::create(['name' => 'Backend Developer']); // id 9

        // Data Users (Pengguna Login)
        $admin = User::create([
            'name' => 'Firyanul Rizky',
            'email' => 'firyan2903@gmail.com',
            'password' => Hash::make('123')
        ]);
        $admin2 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'password' => Hash::make('pw111018')
        ]);

        $employee1 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Anul Emp',
            'email' => 'anul29@mail.com',
            'password' => Hash::make('123456')
        ]);
        $employee2 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Manajemen',
            'email' => 'manajemen@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee3 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Perawat',
            'email' => 'perawat@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee4 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Bidan',
            'email' => 'bidan@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee5 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Dokter',
            'email' => 'dokter@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee6 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Kasir',
            'email' => 'kasir@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee7 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Farmasi',
            'email' => 'farmasi@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee8 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Front Office',
            'email' => 'front_office@gmail.com',
            'password' => Hash::make('petugas123')
        ]);
        $employee9 = User::create([ // <-- Variabel diubah agar unik
            'name' => 'Petugas Kebersihan',
            'email' => 'petugas_kebersihan@gmail.com',
            'password' => Hash::make('petugas123')
        ]);

        // Data Employees (Detail Karyawan)
        $dob = new DateTime('1999-03-29');
        $join = new DateTime('2021-09-15');
        $admin_emp = Employee::create([
            'user_id' => 1,
            'first_name' => 'Firyanul',
            'last_name' => 'Rizky',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Male',
            'desg' => 'Manager',
            'department_id' => 1,
            'join_date' => $join->format('Y-m-d'),
            'salary' => 6500000,
            'photo' => 'download.png'
        ]);
        $admin_emp_2 = Employee::create([
            'user_id' => 2,
            'first_name' => 'Admin',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Male',
            'desg' => 'Manager',
            'department_id' => 1,
            'join_date' => $join->format('Y-m-d'),
            'salary' => 6500000,
            'photo' => 'admin.png'
        ]);
        $employee_emp = Employee::create([
            'user_id' => 3,
            'first_name' => 'Anul',
            'last_name' => 'Emp',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Male',
            'desg' => 'Staff',
            'department_id' => 9, // Sekarang ID 9 sudah ada
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'download_1639112200.png'
        ]);
        $employee_emp_2 = Employee::create([
            'user_id' => 4,
            'first_name' => 'Manajemen',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Male',
            'desg' => 'Manager',
            'department_id' => 1,
            'join_date' => $join->format('Y-m-d'),
            'salary' => 6500000,
            'photo' => 'manajemen.png'
        ]);
        $employee_emp_3 = Employee::create([
            'user_id' => 5,
            'first_name' => 'Perawat',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '2',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'perawat.png'
        ]);
        $employee_emp_4 = Employee::create([
            'user_id' => 6,
            'first_name' => 'Bidan',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '3',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'bidan.png'
        ]);
        $employee_emp_5 = Employee::create([
            'user_id' => 7,
            'first_name' => 'Dokter',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '4',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'dokter.png'
        ]);
        $employee_emp_6 = Employee::create([
            'user_id' => 8,
            'first_name' => 'Kasir',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '5',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'kasir.png'
        ]);
        $employee_emp_7 = Employee::create([
            'user_id' => 9,
            'first_name' => 'Farmasi',
            'last_name' => '',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '6',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'farmasi.png'
        ]);
        $employee_emp_8 = Employee::create([
            'user_id' => 10,
            'first_name' => 'Front',
            'last_name' => 'Office',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Male',
            'desg' => 'Staff',
            'department_id' => '7',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'front_office.png'
        ]);
        $employee_emp_9 = Employee::create([
            'user_id' => 11,
            'first_name' => 'Petugas',
            'last_name' => 'Kebersihan',
            'dob' => $dob->format('Y-m-d'),
            'sex' => 'Female',
            'desg' => 'Staff',
            'department_id' => '8',
            'join_date' => $join->format('Y-m-d'),
            'salary' => 300000,
            'photo' => 'petugas_kebersihan.png'
        ]);


        // Data Role_User (Penghubung)
        $create = Carbon::create(2021, 8, 17, 10, 00, 23, 'Asia/Jakarta');
        $update = Carbon::create(2021, 8, 17, 17, 00, 23, 'Asia/Jakarta');

        // Loop untuk Admin (user_id 1 dan 2)
        for($j=1; $j<=2; $j++) {
            DB::table('role_user')->insert([
                'role_id' => 1,
                'user_id' => $j
            ]);
        }

        // Loop untuk Karyawan (user_id 3 sampai 11)
        for($i=3; $i<=11; $i++) {
            DB::table('role_user')->insert([
                'role_id' => 2,
                'user_id' => $i
            ]);
        }

        // Data Attendances (Absensi)
        for($k=3; $k<=11; $k++) { 
            $attendance = Attendance::create([
                'employee_id' => $k,
                'entry_ip' => '127.0.0.1',
                'entry_location' => '',
                'created_at' => $create
            ]);
            $attendance->exit_ip = '127.0.0.1';
            $attendance->exit_location = '';
            $attendance->registered = 'ya';
            $attendance->updated_at = $update;
            $attendance->save();
            $create->addDay();
            $update->addDay();
        }
    }
}