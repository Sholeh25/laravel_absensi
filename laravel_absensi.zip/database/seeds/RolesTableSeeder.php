<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Role;
use App\User;

class RoleSeeder extends Seeder
{
    /**
     * Jalankan seeder untuk membuat role dan user default.
     *
     * @return void
     */
    public function run()
    {
        // 1️⃣ Buat Role Admin & Employee jika belum ada
        $adminRole = Role::firstOrCreate(['name' => 'admin']);
        $employeeRole = Role::firstOrCreate(['name' => 'employee']);

        // 2️⃣ Buat user admin default
        $admin = User::firstOrCreate(
            ['email' => 'admin@gmail.com'],
            [
                'name' => 'Administrator',
                'password' => Hash::make('12345678'),
            ]
        );

        // 3️⃣ Hubungkan admin ke role admin (pivot role_user)
        if (!$admin->roles()->where('name', 'admin')->exists()) {
            $admin->roles()->attach($adminRole->id);
        }

        echo "✅ Seeder berhasil dijalankan.\n";
        echo "Akun admin: admin@gmail.com | Password: 12345678\n";
    }
}
