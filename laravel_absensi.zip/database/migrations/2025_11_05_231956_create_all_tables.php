<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // 1. Tabel Roles
    Schema::create('roles', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->timestamps();
     });
        // 2. Tabel Users
    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('email')->unique();
        $table->timestamp('email_verified_at')->nullable();
        $table->string('password');
        $table->rememberToken();
        $table->timestamps();
    });
        // 3. Tabel Role User
    Schema::create('role_user', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('role_id');
        $table->unsignedBigInteger('user_id');
        $table->timestamps();
    });
    // 4. Tabel Departments
    Schema::create('departments', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->timestamps();
    });
    // 5. Tabel Employees (Lengkap)
    Schema::create('employees', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('user_id');
        $table->string('first_name');
        $table->string('last_name');
        $table->date('dob');
        $table->string('sex');
        $table->string('desg');
        $table->unsignedBigInteger('department_id');
        $table->date('join_date');
        $table->decimal('salary', 15, 2);
        $table->string('photo')->default('user.png');
        $table->timestamps();
    });
    // 6. Tabel Attendances (Lengkap dengan Koordinat)
    Schema::create('attendances', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('employee_id');
        $table->string('entry_ip')->nullable();
        $table->string('entry_location')->nullable();
        $table->string('entry_latitude')->nullable();
        $table->string('entry_longitude')->nullable();
        $table->string('exit_ip')->nullable();
        $table->string('exit_location')->nullable();
        $table->string('exit_latitude')->nullable();
        $table->string('exit_longitude')->nullable();
        $table->string('registered')->nullable();
        $table->time('time')->nullable();
        $table->timestamps();
    });
    // 7. Tabel Penggajian
    Schema::create('penggajian', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('employee_id');
        $table->decimal('gaji_pokok', 15, 2);
        $table->decimal('tunjangan', 15, 2)->nullable();
        $table->timestamps();
    });
    // 8. Tabel Lainnya (Password Resets, Failed Jobs, Leaves, Holidays, Expenses)
    Schema::create('password_resets', function (Blueprint $table) {
        $table->string('email')->index();
        $table->string('token');
        $table->timestamp('created_at')->nullable();
    });
    Schema::create('failed_jobs', function (Blueprint $table) {
        $table->id();
        $table->text('connection');
        $table->text('queue');
        $table->longText('payload');
        $table->longText('exception');
        $table->timestamp('failed_at')->useCurrent();
    });
    Schema::create('leaves', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('employee_id');
        $table->string('reason');
        $table->text('description')->nullable();
        $table->string('half_day');
        $table->date('start_date');
        $table->date('end_date')->nullable();
        $table->string('status')->default('pending');
        $table->timestamps();
    });
    Schema::create('holidays', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->date('start_date');
        $table->date('end_date')->nullable();
        $table->timestamps();
    });
    Schema::create('expenses', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('employee_id');
        $table->string('reason');
        $table->text('description')->nullable();
        $table->decimal('amount', 15, 2);
        $table->string('status')->default('pending');
        $table->string('receipt')->nullable();
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('all_tables');
    }
};
