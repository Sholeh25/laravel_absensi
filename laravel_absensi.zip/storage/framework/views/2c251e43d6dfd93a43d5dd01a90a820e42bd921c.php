<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <a href="<?php echo e(auth()->user()->hasRole('admin') ? route('admin.index') : route('employee.index')); ?>"
       class="brand-link text-center">
        <span class="brand-text font-weight-light">Web Absensi</span>
    </a>

    <div class="sidebar">

        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <?php if(auth()->user()->employee && auth()->user()->employee->photo): ?>
                    <img src="<?php echo e(asset('storage/employee_photos/' . auth()->user()->employee->photo)); ?>"
                         class="img-circle elevation-2">
                <?php else: ?>
                    <img src="<?php echo e(asset('dist/img/firyanul.png')); ?>"
                         class="img-circle elevation-2">
                <?php endif; ?>
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(auth()->user()->name); ?></a>
            </div>
        </div>

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column"
                data-widget="treeview"
                role="menu"
                data-accordion="false">

                
                <?php if(auth()->user()->hasRole('admin')): ?>
                    
                    <?php echo $__env->make('includes.admin.sidebar_items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                
                
                
                <?php elseif(auth()->user()->hasRole('employee')): ?>
                    <?php echo $__env->make('includes.employee.sidebar_items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <?php endif; ?>

            </ul>
        </nav>

    </div>
</aside><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/includes/main_sidebar.blade.php ENDPATH**/ ?>