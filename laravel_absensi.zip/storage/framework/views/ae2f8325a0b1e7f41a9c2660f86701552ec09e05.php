<?php if(session('success')): ?>
<div class="alert alert-success text-center">
<h4><?php echo e(session('success')); ?></h4>
</div>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/messages/alerts.blade.php ENDPATH**/ ?>