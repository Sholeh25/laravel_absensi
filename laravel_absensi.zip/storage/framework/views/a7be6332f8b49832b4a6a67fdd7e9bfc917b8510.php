        

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Daftar Absensi</h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('employee.index')); ?>">Dashboard Karyawan</a>
                        </li>
                        <li class="breadcrumb-item active">
                            Daftar Absensi
                        </li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 mx-auto">
                    <div class="card">
                        <div class="card-header">
                                <h5 class="text-center text-primary" style="text-align: center !important">Cari Absensi dengan rentang tanggal</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8 mx-auto text-center">
                                    <form action="<?php echo e(route('employee.attendance.index')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <fieldset>
                                            <div class="form-group">
                                                <label for="">Rentang Tanggal</label>
                                                <input type="text" name="date_range" placeholder="Start Date" class="form-control text-center"
                                                id="date_range"
                                                >
                                                <?php $__errorArgs = ['date_range'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="ml-2 text-danger">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </fieldset>
                                        
                                            <input type="submit" name="" class="btn btn-primary" value="Submit">
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg mx-auto">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="card-title text-center">
                                Absensi
                                <?php if($filter): ?>
                                    dari rentang
                                <?php endif; ?>
                            </div>
                            
                        </div>
                        <div class="card-body">
                            <?php if($attendances->count()): ?>
                            <table class="table table-bordered table-hover" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Waktu Absensi</th>
                                        <th>Lokasi Absensi</th>
                                        <th>Waktu Selesai</th>
                                        <th>Lokasi Selesai</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <?php if($attendance->registered == 'ya'): ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-success">Hadir</span> </h5></td>
                                        <td><?php echo e($attendance->created_at->format('H:i:s')); ?></td>
                                        <td><?php echo e($attendance->entry_location); ?></td>
                                        <td><?php echo e($attendance->updated_at->format('H:i:s')); ?></td>
                                        <td><?php echo e($attendance->exit_location); ?></td>
                                        <?php elseif($attendance->registered == 'no'): ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-danger">Absen</span> </h5></td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <?php elseif($attendance->registered == 'sun'): ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-info">Minggu</span> </h5></td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <?php elseif($attendance->registered == 'leave'): ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-info">Leave</span> </h5></td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <?php elseif($attendance->registered == 'holiday'): ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-success">Hari Libur</span> </h5></td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <td class="text-center">Belum Ada Riwayat</td>
                                        <?php else: ?>
                                        <td><?php echo e($attendance->created_at->format('d-m-Y')); ?></td>
                                        <td><h5 class="text-center"><span class="badge badge-pill badge-warning">Setengah Jam Kerja</span> </h5></td>
                                        <td><?php echo e($attendance->created_at->format('H:i:s')); ?></td>
                                        <td><?php echo e($attendance->entry_location); ?></td>
                                        <td> - </td>
                                        <td> - </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="alert alert-info text-center" style="width:50%; margin: 0 auto">
                                <h4>Data Tidak Ada</h4>
                            </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                    <!-- general form elements -->
                    
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>

<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            responsive:true,
            autoWidth: false,
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['copy','excel', 'csv', 'pdf']
                }
            ]
        });
        $('#date_range').daterangepicker({
            "maxDate": new Date(),
            "locale": {
                "format": "DD-MM-YYYY",
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/employee/attendance/index.blade.php ENDPATH**/ ?>