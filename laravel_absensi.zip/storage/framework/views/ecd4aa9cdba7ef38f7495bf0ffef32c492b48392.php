


<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    
    <ul class="navbar-nav">
        
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li>

        
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role === 'admin'): ?>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('admin.index')); ?>" class="nav-link">
                        Dashboard Admin
                    </a>
                </li>
            <?php elseif(Auth::user()->role === 'employee'): ?>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('employee.index')); ?>" class="nav-link">
                        Dashboard Karyawan
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>

    
    <ul class="navbar-nav ml-auto">

        
        <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">
                <i class="far fa-clock"></i>
                <span id="navbar-time"><?php echo e(now()->translatedFormat('d M Y, H:i')); ?></span>
            </a>
        </li>

        
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item dropdown user-menu">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                
                <?php if(Auth::user()->photo && file_exists(public_path('storage/profile/' . Auth::user()->photo))): ?>
                    <img src="<?php echo e(asset('storage/profile/' . Auth::user()->photo)); ?>" class="user-image img-circle elevation-2" alt="User Image">
                <?php else: ?>
                    <img src="<?php echo e(asset('img/default-user.png')); ?>" class="user-image img-circle elevation-2" alt="User Image">
                <?php endif; ?>

                
                <span class="d-none d-md-inline"><?php echo e(Auth::user()->name ?? 'User'); ?></span>
            </a>

            
            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                
                <li class="user-header bg-primary">
                    <?php if(Auth::user()->photo && file_exists(public_path('storage/profile/' . Auth::user()->photo))): ?>
                        <img src="<?php echo e(asset('storage/profile/' . Auth::user()->photo)); ?>" class="img-circle elevation-2" alt="User Image">
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/default-user.png')); ?>" class="img-circle elevation-2" alt="User Image">
                    <?php endif; ?>
                    <p>
                        <?php echo e(Auth::user()->name ?? 'User'); ?>

                        <small><?php echo e(ucfirst(Auth::user()->role ?? 'Guest')); ?></small>
                    </p>
                </li>

                
                <li class="user-footer">
                    
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.profile')); ?>" class="btn btn-default btn-flat">
                            <i class="fas fa-user"></i> Profil
                        </a>
                    <?php elseif(Auth::user()->role === 'employee'): ?>
                        <a href="<?php echo e(route('employee.profile')); ?>" class="btn btn-default btn-flat">
                            <i class="fas fa-user"></i> Profil
                        </a>
                    <?php endif; ?>

                    
                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat float-right"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i> Keluar
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </li>
        <?php endif; ?>

    </ul>
</nav>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        function updateTime() {
            const now = new Date();
            const formatted = now.toLocaleString('id-ID', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            document.getElementById('navbar-time').textContent = formatted;
        }
        updateTime();
        setInterval(updateTime, 60000);
    });
</script>
<?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/includes/navbar.blade.php ENDPATH**/ ?>