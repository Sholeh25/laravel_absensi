<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<div class="content-header">
    <div class="container-fluid">

        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Dashboard Karyawan</h1>
            </div>

            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="#">Halaman Utama</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Dashboard
                    </li>
                </ol>
            </div>
        </div>

    </div>
</div>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-8 mx-auto">

                <div class="jumbotron">

                    <h1 class="display-5 text-primary">
                        Selamat Datang di Panel Karyawan
                    </h1>

                    <p class="lead">
                        Sistem Absensi & Payroll
                    </p>

                    <hr class="my-4">

                    <?php
                        $user = auth()->user();
                        $employee = $user->employee ?? null;
                    ?>

                    <p>
                        Silakan mulai absensi,
                        <strong>
                        <?php if($employee && $employee->sex === 'Male'): ?>
                            Bapak <?php echo e($employee->first_name . ' ' . $employee->last_name); ?>

                        <?php elseif($employee && $employee->sex !== 'Male'): ?>
                            Ibu <?php echo e($employee->first_name . ' ' . $employee->last_name); ?>

                        <?php else: ?>
                            <?php echo e($user->name); ?>

                        <?php endif; ?>
                        </strong>
                    </p>

                </div>

            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/employee/index.blade.php ENDPATH**/ ?>