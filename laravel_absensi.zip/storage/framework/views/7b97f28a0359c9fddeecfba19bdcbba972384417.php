



<li class="nav-item">
    <a href="<?php echo e(route('employee.index')); ?>" class="nav-link <?php echo e(request()->routeIs('employee.index') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>Dashboard Karyawan</p>
    </a>
</li>


<li class="nav-item has-treeview <?php echo e(request()->is('employee/attendance*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(request()->is('employee/attendance*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-clock"></i>
        <p>
            Absensi
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('employee.attendance.create')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.attendance.create') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Absensi Hari Ini</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('employee.attendance.index')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.attendance.index') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Absensi</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item has-treeview <?php echo e(request()->is('employee/leaves*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(request()->is('employee/leaves*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-calendar-check"></i>
        <p>
            Cuti
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('employee.leaves.create')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.leaves.create') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Ajukan Cuti</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('employee.leaves.index')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.leaves.index') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Cuti</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item has-treeview <?php echo e(request()->is('employee/expenses*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(request()->is('employee/expenses*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-stopwatch"></i>
        <p>
            Lembur
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('employee.expenses.create')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.expenses.create') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Klaim Lembur</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('employee.expenses.index')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.expenses.index') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Lembur</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item has-treeview <?php echo e(request()->is('employee/self*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(request()->is('employee/self*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-file-invoice-dollar"></i>
        <p>
            Report
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('employee.self.salary_slip')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.self.salary_slip') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Slip Gaji</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('employee.self.holidays')); ?>" 
               class="nav-link <?php echo e(request()->routeIs('employee.self.holidays') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Hari Libur</p>
            </a>
        </li>
    </ul>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('employee.profile')); ?>" class="nav-link <?php echo e(request()->routeIs('employee.profile') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-user"></i>
        <p>Profil Saya</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('logout')); ?>" 
       class="nav-link"
       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="nav-icon fas fa-sign-out-alt text-danger"></i>
        <p>Logout</p>
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</li>
<?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/includes/employee/sidebar_items.blade.php ENDPATH**/ ?>