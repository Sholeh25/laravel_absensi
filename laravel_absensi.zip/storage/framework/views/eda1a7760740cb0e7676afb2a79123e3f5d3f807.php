        

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Profil</h1>
            </div>
            <!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Profil
                    </li>
                </ol>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card card-primary">
                    <div class="card-header">
                        <h5 class="text-center mt-2">Profil Karyawan</h5>
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('messages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row mb-3">
                            <div class="col text-center mx-auto">
                                <img src="/storage/employee_photos/<?php echo e($employee->photo); ?>" class="rounded-circle img-fluid" alt=""
                                style="box-shadow: 2px 4px rgba(0,0,0,0.1)"
                                >
                            </div>
                        </div>
                        <table class="table profile-table table-hover">
                            <tr>
                                <td>Nama Awal</td>
                                <td><?php echo e($employee->first_name); ?></td>
                            </tr>
                            <tr>
                                <td>Nama Akhir</td>
                                <td><?php echo e($employee->last_name); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Lahir</td>
                                <td><?php echo e($employee->dob->format('d M, Y')); ?></td>
                            </tr>
                            <tr>
                                <td>Jenis Kelamin</td>
                                <td><?php echo e($employee->sex); ?></td>
                            </tr>
                            
                            <tr>
                                <td>Tanggal Bergabung</td>
                                <td><?php echo e($employee->join_date->format('d M, Y')); ?></td>
                            </tr>
                            <tr>
                                <td>Jabatan</td>
                                <td><?php echo e($employee->desg); ?></td>
                            </tr>
                            <tr>
                                <td>Department</td>
                                <td><?php echo e($employee->department->name); ?></td>
                            </tr>
                            <tr>
                                <td>Gaji</td>
                                <td>Rp. <?php echo e($employee->salary); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="card-footer text-center" style="height: 2rem">
                        
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/admin/employees/profile.blade.php ENDPATH**/ ?>