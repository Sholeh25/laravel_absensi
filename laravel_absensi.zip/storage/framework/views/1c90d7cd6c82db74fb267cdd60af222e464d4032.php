<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="col-md-6 col-lg-4">
        <div class="card shadow-sm border-0 rounded-3">

            <div class="card-header text-center bg-white border-0 pt-4 pb-1">
                <img src="<?php echo e(asset('img/LOGO FORESTHREE.jpg')); ?>"
                     alt="Logo Foresthree"
                     style="width: 90px; height: auto; margin-bottom: 15px;">

                <h4 class="mb-0 fw-bold">Login Sistem</h4>
                <small class="text-muted">Admin & Karyawan</small>
            </div>

            <div class="card-body px-4 pb-4">

                <form method="POST" action="<?php echo e(route('login')); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Alamat E-Mail</label>
                        <input id="email"
                               type="email"
                               class="form-control rounded-3 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="email"
                               value="<?php echo e(old('email')); ?>"
                               required
                               autofocus
                               placeholder="Masukkan email Anda">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input id="password"
                               type="password"
                               class="form-control rounded-3 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="password"
                               required
                               placeholder="Masukkan password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="form-check mb-3">
                        <input class="form-check-input"
                               type="checkbox"
                               name="remember"
                               id="remember"
                               <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="remember">
                            Ingat Saya
                        </label>
                    </div>

                    
                    <button type="submit" class="btn btn-primary w-100 fw-bold rounded-3 py-2">
                        Login
                    </button>

                    
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger mt-3 text-center rounded-3">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/auth/login.blade.php ENDPATH**/ ?>