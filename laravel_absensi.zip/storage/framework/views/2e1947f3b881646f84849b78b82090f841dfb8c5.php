        

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Daftar Lembur</h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('employee.index')); ?>">Dashboard Karyawan</a>
                        </li>
                        <li class="breadcrumb-item active">
                            Daftar Lembur
                        </li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <!-- general form elements -->
                    <?php echo $__env->make('messages.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Daftar Lembur</h3>
                        </div>
                        <div class="card-body">
                            <?php if($expenses->count()): ?>
                            <table class="table table-hover" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Diajukan pada</th>
                                        <th>Judul Tugas</th>
                                        <th>Status</th>
                                        <th>Estimasi Upah Lembur</th>
                                        <th class="none">Deskripsi</th>
                                        <th class="none">Bukti Absen Lembur</th>
                                        <th class="none">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($expense->created_at->format('d-m-Y')); ?></td>
                                        <td><?php echo e($expense->reason); ?></td>
                                        <td>
                                            <h5>
                                                <span 
                                                <?php if($expense->status == 'pending'): ?>
                                                    class="badge badge-pill badge-warning"
                                                <?php elseif($expense->status == 'ditolak'): ?>
                                                    class="badge badge-pill badge-danger"
                                                <?php elseif($expense->status == 'diterima'): ?>
                                                    class="badge badge-pill badge-success"
                                                <?php endif; ?>
                                                >
                                                    <?php echo e(ucfirst($expense->status)); ?>

                                                </span> 
                                            </h5>
                                        </td>
                                        <td><?php echo e($expense->amount); ?></td>
                                        <td><?php echo e($expense->description); ?></td>
                                        <td>
                                            <?php if($expense->receipt): ?>
                                            <button type="button" class="btn btn-flat btn-primary" data-toggle="modal" data-target="#exampleModalCenter<?php echo e($index + 1); ?>">
                                                Lihat Bukti Absen Lembur
                                            </button>  
                                            <?php else: ?>
                                            Belum Ada File Upload
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.expenses.edit', $expense->id)); ?>" class="btn btn-flat btn-warning">Edit</a>
                                            <button type="button" class="btn btn-flat btn-danger" 
                                            data-toggle="modal" 
                                            data-target="#deleteModalCenter<?php echo e($index + 1); ?>"
                                            >
                                                Hapus
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php for($i = 1; $i < $expenses->count()+1; $i++): ?>
                                <?php if($expenses->get($i-1)->receipt ): ?>
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModalCenter<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle1<?php echo e($i); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-body text-center">
                                                    <img src="/storage/receipts/<?php echo e($expenses->get($i-1)->receipt); ?>" class="img-fluid" alt="Receipt Image" style="width: auto; height:100%">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.modal -->
                                <?php endif; ?>
                                <!-- Modal -->
                                <div class="modal fade" id="deleteModalCenter<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalCenterTitle1<?php echo e($i); ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="card card-danger">
                                                <div class="card-header">
                                                    <h5 style="text-align: center !important">Yakin ingin dihapus ?</h5>
                                                </div>
                                                <div class="card-body text-center d-flex" style="justify-content: center">
                                                    
                                                    <button type="button" class="btn flat btn-secondary" data-dismiss="modal">No</button>
                                                    
                                                    <form 
                                                    action="<?php echo e(route('employee.expenses.delete', $expenses->get($i-1)->id)); ?>"
                                                    method="POST"
                                                    >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn flat btn-danger ml-1">Yes</button>
                                                    </form>
                                                </div>
                                                <div class="card-footer text-center">
                                                    <small>Aksi ini tidak bisa dibatalkan</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.modal -->
                            <?php endfor; ?>
                            <?php else: ?>
                            <div class="alert alert-info text-center" style="width:50%; margin: 0 auto">
                                <h4>Tidak Ada Data</h4>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>

<script>
$(document).ready(function(){
    
    $('#dataTable').DataTable({
        responsive:true,
        autoWidth: false,
        dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['copy','excel', 'csv', 'pdf']
                }
            ]
    });
    
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/employee/expenses/index.blade.php ENDPATH**/ ?>