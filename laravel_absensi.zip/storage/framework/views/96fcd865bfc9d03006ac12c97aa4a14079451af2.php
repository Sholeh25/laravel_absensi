<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard Admin</h1>
            </div><div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Halaman Utama</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div></div></div></div>
<section class="content">
    <div class="container-fluid">
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-lg border-0 rounded-lg">
                    <div class="card-body text-center p-5">
                        
                        <?php if(optional(Auth::user()->employee)->photo): ?>
                            <img src="<?php echo e(asset('storage/employee_photos/' . Auth::user()->employee->photo)); ?>" alt="User Photo" class="mb-4 d-block mx-auto img-circle elevation-2" style="width: 100px; height: 100px; object-fit: cover;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('dist/img/firyanul.png')); ?>" alt="Default Logo" class="mb-4 d-block mx-auto img-circle elevation-2" style="width: 100px; height: 100px; object-fit: cover;">
                        <?php endif; ?>
                        
                        <h1 class="display-5 text-primary font-weight-bold mb-3">
                            Selamat Datang, <?php echo e(Auth::user()->name); ?>!
                        </h1>
                        <p class="lead mb-4" style="color: #555;">
                            Anda telah berhasil masuk ke <strong>Panel Admin Website Absensi</strong>.
                            <br>
                            Sistem ini siap digunakan untuk mendukung operasional <strong>PT Foresthree Waralaba Indonesia</strong>.
                        </p>
                        
                        <hr>

                        <div class="mt-4">
                            <p>Menu Cepat:</p>
                            <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-outline-primary mx-1"><i class="fas fa-users"></i> Karyawan</a>
                            <a href="<?php echo e(route('admin.employees.attendance')); ?>" class="btn btn-outline-success mx-1"><i class="fas fa-clock"></i> Absensi</a>
                            <a href="<?php echo e(route('admin.penggajian.index')); ?>" class="btn btn-outline-info mx-1"><i class="fas fa-money-bill-wave"></i> Penggajian</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div></section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel_absensi\resources\views/admin/index.blade.php ENDPATH**/ ?>