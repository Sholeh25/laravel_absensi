@extends('layouts.app')        

@section('content')

<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 align-items-center">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                    <i class="fas fa-user-circle"></i> Profil Saya
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="{{ route('employee.index') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item active">Profil</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                
                {{-- Card Profile --}}
                <div class="card card-primary card-outline shadow-sm">
                    <div class="card-header bg-primary text-white text-center">
                        <h5 class="mb-0"><i class="fas fa-id-badge"></i> Profil Karyawan</h5>
                    </div>

                    <div class="card-body">
                        @include('messages.alerts')

                        {{-- Foto Profil --}}
                        <div class="row mb-4">
                            <div class="col text-center">
                                @if($employee->photo && file_exists(public_path('storage/employee_photos/'.$employee->photo)))
                                    <img src="{{ asset('storage/employee_photos/'.$employee->photo) }}" 
                                         class="rounded-circle img-thumbnail" width="150" height="150"
                                         style="object-fit: cover; box-shadow: 2px 4px 10px rgba(0,0,0,0.1)">
                                @else
                                    <img src="{{ asset('img/default-user.png') }}" 
                                         class="rounded-circle img-thumbnail" width="150" height="150"
                                         style="object-fit: cover; box-shadow: 2px 4px 10px rgba(0,0,0,0.1)">
                                @endif
                            </div>
                        </div>

                        {{-- Tabel Data Profil --}}
                        <table class="table table-hover table-bordered profile-table">
                            <tbody>
                                <tr>
                                    <th width="40%">Nama Awal</th>
                                    <td>{{ $employee->first_name ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Nama Akhir</th>
                                    <td>{{ $employee->last_name ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Tanggal Lahir</th>
                                    <td>{{ optional($employee->dob)->format('d M, Y') ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Jenis Kelamin</th>
                                    <td>{{ $employee->sex ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Tanggal Bergabung</th>
                                    <td>{{ optional($employee->join_date)->format('d M, Y') ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Jabatan</th>
                                    <td>{{ $employee->desg ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Departemen</th>
                                    <td>{{ $employee->department->name ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <th>Gaji Pokok</th>
                                    <td>Rp. {{ number_format($employee->salary ?? 0, 0, ',', '.') }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    {{-- Footer Button --}}
                    <div class="card-footer text-center">
                        <a href="{{ route('employee.profile-edit', $employee->id) }}" class="btn btn-primary btn-flat">
                            <i class="fas fa-edit"></i> Edit Profil
                        </a>
                        <a href="{{ route('employee.reset-password') }}" class="btn btn-danger btn-flat">
                            <i class="fas fa-key"></i> Ganti Password
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

@endsection
