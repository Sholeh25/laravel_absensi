@extends('layouts.app')

@section('content')

<!-- Content Header -->
<div class="content-header">
    <div class="container-fluid">

        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Dashboard Karyawan</h1>
            </div>

            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="#">Halaman Utama</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Dashboard
                    </li>
                </ol>
            </div>
        </div>

    </div>
</div>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-8 mx-auto">

                <div class="jumbotron">

                    <h1 class="display-5 text-primary">
                        Selamat Datang di Panel Karyawan
                    </h1>

                    <p class="lead">
                        Sistem Absensi & Payroll
                    </p>

                    <hr class="my-4">

                    @php
                        $user = auth()->user();
                        $employee = $user->employee ?? null;
                    @endphp

                    <p>
                        Silakan mulai absensi,
                        <strong>
                        @if ($employee && $employee->sex === 'Male')
                            Bapak {{ $employee->first_name . ' ' . $employee->last_name }}
                        @elseif ($employee && $employee->sex !== 'Male')
                            Ibu {{ $employee->first_name . ' ' . $employee->last_name }}
                        @else
                            {{ $user->name }}
                        @endif
                        </strong>
                    </p>

                </div>

            </div>
        </div>

    </div>
</section>

@endsection
