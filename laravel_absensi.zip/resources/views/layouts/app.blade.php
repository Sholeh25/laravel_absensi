<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Web Absensi')</title>

    {{-- Favicon --}}
    <link rel="icon" href="{{ asset('img/partner.png') }}">

    {{-- Responsiveness --}}
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    {{-- ======================== --}}
    {{-- STYLES --}}
    {{-- ======================== --}}
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('dist/css/adminlte.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">

    {{-- Stack tambahan (per page) --}}
    @stack('styles')
</head>

@guest
{{-- ======================================================= --}}
{{--  HALAMAN LOGIN / TAMU --}}
{{-- ======================================================= --}}
<body class="hold-transition login-page">

    {{-- Flash message global --}}
    <div class="container mt-3">
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif
    </div>

    {{-- Konten login --}}
    @yield('content')

    {{-- Script minimal login --}}
    <script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    @stack('scripts')
</body>

@else
{{-- ======================================================= --}}
{{--  HALAMAN UTAMA (SETELAH LOGIN) --}}
{{-- ======================================================= --}}
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">

    {{-- Navbar --}}
    @include('includes.navbar')

    {{-- Sidebar utama (otomatis adaptif admin/employee) --}}
    @include('includes.main_sidebar')

    {{-- ======================== --}}
    {{-- CONTENT WRAPPER --}}
    {{-- ======================== --}}
    <div class="content-wrapper">
        <section class="content pt-3">
            <div class="container-fluid">
                {{-- Flash message global --}}
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                {{-- Konten halaman --}}
                @yield('content')
            </div>
        </section>
    </div>

    {{-- ======================== --}}
    {{-- FOOTER --}}
    {{-- ======================== --}}
    <footer class="main-footer text-center">
        <strong>Dibuat © Oktober 2025 oleh Solehhudin.</strong>
        <div class="float-right d-none d-sm-inline-block">
            <b>Versi</b> 1.0
        </div>
    </footer>
</div>

{{-- ======================== --}}
{{-- SCRIPTS --}}
{{-- ======================== --}}
<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js') }}"></script>
<script src="{{ asset('dist/js/adminlte.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/moment/moment.min.js') }}"></script>
<script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>

{{-- Stack tambahan (per page) --}}
@stack('scripts')
</body>
@endguest
</html>
