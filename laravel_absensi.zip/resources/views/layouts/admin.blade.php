<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel</title>

    <!-- CSS AdminLTE -->
    <link rel="stylesheet" href="{{ asset('dist/css/adminlte.min.css') }}">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">

    <!-- Custom CSS (opsional) -->
    <style>
        .content-wrapper {
            padding: 20px;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">

<div class="wrapper">

    {{-- ✅ Navbar untuk Admin --}}
    @include('includes.navbar_admin')

    {{-- ✅ Sidebar untuk Admin --}}
    @include('includes.sidebar_admin')

    {{-- ✅ Area konten --}}
    <div class="content-wrapper">
        @yield('content')
    </div>

    {{-- Footer (opsional) --}}
    <footer class="main-footer text-center">
        <strong>PT Foresthree Waralaba Indonesia</strong>
    </footer>

</div>

<!-- JS AdminLTE -->
<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('dist/js/adminlte.min.js') }}"></script>

</body>
</html>
