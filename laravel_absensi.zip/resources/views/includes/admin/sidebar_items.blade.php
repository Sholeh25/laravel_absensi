{{-- resources/views/includes/admin/sidebar_items.blade.php --}}

<li class="nav-item">
    <a href="{{ route('admin.index') }}" class="nav-link {{ request()->routeIs('admin.index') ? 'active' : '' }}">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>Dashboard Admin</p>
    </a>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon far fa-address-card"></i>
        <p>Karyawan <i class="fas fa-angle-left right"></i></p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a href="{{ route('admin.employees.create') }}" class="nav-link"><i class="far fa-circle nav-icon"></i>Tambah Karyawan</a></li>
        <li class="nav-item"><a href="{{ route('admin.employees.index') }}" class="nav-link"><i class="far fa-circle nav-icon"></i>Daftar Karyawan</a></li>
        <li class="nav-item"><a href="{{ route('admin.employees.attendance') }}" class="nav-link"><i class="far fa-circle nav-icon"></i>Absensi Karyawan</a></li>
    </ul>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-calendar-check-o"></i>
        <p>Daftar Cuti <i class="fas fa-angle-left right"></i></p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a href="{{ route('admin.leaves.index') }}" class="nav-link"><i class="fas fa-list nav-icon"></i>Cuti</a></li>
    </ul>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-clock"></i>
        <p>Kelola Lembur <i class="fas fa-angle-left right"></i></p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a href="{{ route('admin.expenses.setting_index') }}" class="nav-link"><i class="far fa-circle nav-icon"></i>Setting Lembur</a></li>
        <li class="nav-item"><a href="{{ route('admin.expenses.index') }}" class="nav-link"><i class="far fa-circle nav-icon"></i>Daftar Lembur</a></li>
    </ul>
</li>

<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fa fa-calendar-minus-o"></i>
        <p>Hari Libur <i class="fas fa-angle-left right"></i></p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a href="{{ route('admin.holidays.create') }}" class="nav-link"><i class="fas fa-plus-circle nav-icon"></i>Tambah Hari Libur</a></li>
        <li class="nav-item"><a href="{{ route('admin.holidays.index') }}" class="nav-link"><i class="fas fa-calendar-alt nav-icon"></i>Daftar Hari Libur</a></li>
    </ul>
</li>

<li class="nav-item">
    <a href="{{ route('admin.penggajian.index') }}" class="nav-link">
        <i class="nav-icon fas fa-money-bill-wave"></i>
        <p>Penggajian</p>
    </a>
</li>
