<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <!-- Brand Logo -->
    <a href="{{ route('admin.index') }}" class="brand-link">
        <img src="{{ asset('img/partner.png') }}" 
             alt="Logo" 
             class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span class="brand-text font-weight-light">Admin Panel</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">

        <!-- User panel -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">

            <div class="image">
                @if(optional(Auth::user()->employee)->photo)
                    <img src="{{ asset('storage/employee_photos/' . Auth::user()->employee->photo) }}"
                         class="img-circle elevation-2"
                         alt="User Image" style="object-fit: cover;">
                @else
                    <img src="{{ asset('dist/img/firyanul.png') }}" 
                         class="img-circle elevation-2"
                         alt="User Image">
                @endif
            </div>

            <div class="info">
                <a href="{{ route('admin.profile') }}" class="d-block">
                    {{ Auth::user()->name }}
                </a>
            </div>

        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview">

                <li class="nav-item">
                    <a href="{{ route('admin.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.employees.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Data Karyawan</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.leaves.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-calendar"></i>
                        <p>Data Cuti</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.expenses.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-money-bill"></i>
                        <p>Pengeluaran Karyawan</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.holidays.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-umbrella-beach"></i>
                        <p>Hari Libur</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.penggajian.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-wallet"></i>
                        <p>Penggajian</p>
                    </a>
                </li>

            </ul>
        </nav>

    </div>

</aside>
