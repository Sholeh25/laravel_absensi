<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <a href="#" class="brand-link text-center">
        <span class="brand-text font-weight-light">Web Absensi</span>
    </a>

    <div class="sidebar">

        {{-- User Panel --}}
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="{{ optional(Auth::user()->employee)->photo
                    ? asset('storage/employee_photos/'.Auth::user()->employee->photo)
                    : asset('dist/img/firyanul.png') }}"
                    class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a class="d-block">{{ Auth::user()->name }}</a>
            </div>
        </div>

        {{-- MENU KARYAWAN --}}
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column">

                <li class="nav-item">
                    <a href="{{ route('employee.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Dashboard Karyawan</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('employee.attendance.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-clock"></i>
                        <p>Absensi</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('employee.leaves.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Pengajuan Cuti</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('employee.expenses.index') }}" class="nav-link">
                        <i class="nav-icon fas fa-receipt"></i>
                        <p>Reimbursement</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('employee.self.holidays') }}" class="nav-link">
                        <i class="nav-icon fas fa-sun"></i>
                        <p>Hari Libur</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('employee.self.salary_slip') }}" class="nav-link">
                        <i class="nav-icon fas fa-file-invoice-dollar"></i>
                        <p>Slip Gaji</p>
                    </a>
                </li>

            </ul>
        </nav>
    </div>
</aside>
