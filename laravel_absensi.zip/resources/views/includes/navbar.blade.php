{{-- resources/views/includes/navbar.blade.php --}}

{{-- NAVBAR UTAMA SISTEM ABSENSI & PAYROLL --}}
<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    {{-- LEFT NAVBAR LINKS --}}
    <ul class="navbar-nav">
        {{-- Tombol Sidebar --}}
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li>

        {{-- Dashboard Link Dinamis berdasarkan Role --}}
        @auth
            @if(Auth::user()->role === 'admin')
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="{{ route('admin.index') }}" class="nav-link">
                        Dashboard Admin
                    </a>
                </li>
            @elseif(Auth::user()->role === 'employee')
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="{{ route('employee.index') }}" class="nav-link">
                        Dashboard Karyawan
                    </a>
                </li>
            @endif
        @endauth
    </ul>

    {{-- RIGHT NAVBAR LINKS --}}
    <ul class="navbar-nav ml-auto">

        {{-- Tanggal & Waktu Real-Time --}}
        <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">
                <i class="far fa-clock"></i>
                <span id="navbar-time">{{ now()->translatedFormat('d M Y, H:i') }}</span>
            </a>
        </li>

        {{-- Dropdown User --}}
        @auth
        <li class="nav-item dropdown user-menu">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                {{-- Foto Profil --}}
                @if(Auth::user()->photo && file_exists(public_path('storage/profile/' . Auth::user()->photo)))
                    <img src="{{ asset('storage/profile/' . Auth::user()->photo) }}" class="user-image img-circle elevation-2" alt="User Image">
                @else
                    <img src="{{ asset('img/default-user.png') }}" class="user-image img-circle elevation-2" alt="User Image">
                @endif

                {{-- Nama User --}}
                <span class="d-none d-md-inline">{{ Auth::user()->name ?? 'User' }}</span>
            </a>

            {{-- DROPDOWN MENU --}}
            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                {{-- Header --}}
                <li class="user-header bg-primary">
                    @if(Auth::user()->photo && file_exists(public_path('storage/profile/' . Auth::user()->photo)))
                        <img src="{{ asset('storage/profile/' . Auth::user()->photo) }}" class="img-circle elevation-2" alt="User Image">
                    @else
                        <img src="{{ asset('img/default-user.png') }}" class="img-circle elevation-2" alt="User Image">
                    @endif
                    <p>
                        {{ Auth::user()->name ?? 'User' }}
                        <small>{{ ucfirst(Auth::user()->role ?? 'Guest') }}</small>
                    </p>
                </li>

                {{-- Footer --}}
                <li class="user-footer">
                    {{-- Tombol ke Profil --}}
                    @if(Auth::user()->role === 'admin')
                        <a href="{{ route('admin.profile') }}" class="btn btn-default btn-flat">
                            <i class="fas fa-user"></i> Profil
                        </a>
                    @elseif(Auth::user()->role === 'employee')
                        <a href="{{ route('employee.profile') }}" class="btn btn-default btn-flat">
                            <i class="fas fa-user"></i> Profil
                        </a>
                    @endif

                    {{-- Tombol Logout --}}
                    <a href="{{ route('logout') }}" class="btn btn-default btn-flat float-right"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i> Keluar
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                </li>
            </ul>
        </li>
        @endauth

    </ul>
</nav>

{{-- SCRIPT UNTUK JAM REALTIME --}}
<script>
    document.addEventListener('DOMContentLoaded', function() {
        function updateTime() {
            const now = new Date();
            const formatted = now.toLocaleString('id-ID', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            document.getElementById('navbar-time').textContent = formatted;
        }
        updateTime();
        setInterval(updateTime, 60000);
    });
</script>
