<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <a href="{{ auth()->user()->hasRole('admin') ? route('admin.index') : route('employee.index') }}"
       class="brand-link text-center">
        <span class="brand-text font-weight-light">Web Absensi</span>
    </a>

    <div class="sidebar">

        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                @if (auth()->user()->employee && auth()->user()->employee->photo)
                    <img src="{{ asset('storage/employee_photos/' . auth()->user()->employee->photo) }}"
                         class="img-circle elevation-2">
                @else
                    <img src="{{ asset('dist/img/firyanul.png') }}"
                         class="img-circle elevation-2">
                @endif
            </div>
            <div class="info">
                <a href="#" class="d-block">{{ auth()->user()->name }}</a>
            </div>
        </div>

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column"
                data-widget="treeview"
                role="menu"
                data-accordion="false">

                {{-- MENU ADMIN --}}
                @if(auth()->user()->hasRole('admin'))
                    {{-- Jika Admin, tampilkan menu Admin dan JANGAN cek yang lain --}}
                    @include('includes.admin.sidebar_items') 
                
                {{-- MENU KARYAWAN --}}
                {{-- KOREKSI: Gunakan @elseif untuk memastikan hanya satu menu yang aktif --}}
                @elseif(auth()->user()->hasRole('employee'))
                    @include('includes.employee.sidebar_items') 
                @endif

            </ul>
        </nav>

    </div>
</aside>