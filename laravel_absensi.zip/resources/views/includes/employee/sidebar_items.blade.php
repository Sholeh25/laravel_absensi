{{-- resources/views/includes/employee/sidebar_items.blade.php --}}
{{-- Sidebar Karyawan --}}

{{-- DASHBOARD --}}
<li class="nav-item">
    <a href="{{ route('employee.index') }}" class="nav-link {{ request()->routeIs('employee.index') ? 'active' : '' }}">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>Dashboard Karyawan</p>
    </a>
</li>

{{-- ABSENSI --}}
<li class="nav-item has-treeview {{ request()->is('employee/attendance*') ? 'menu-open' : '' }}">
    <a href="#" class="nav-link {{ request()->is('employee/attendance*') ? 'active' : '' }}">
        <i class="nav-icon fas fa-clock"></i>
        <p>
            Absensi
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="{{ route('employee.attendance.create') }}" 
               class="nav-link {{ request()->routeIs('employee.attendance.create') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Absensi Hari Ini</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('employee.attendance.index') }}" 
               class="nav-link {{ request()->routeIs('employee.attendance.index') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Absensi</p>
            </a>
        </li>
    </ul>
</li>

{{-- CUTI --}}
<li class="nav-item has-treeview {{ request()->is('employee/leaves*') ? 'menu-open' : '' }}">
    <a href="#" class="nav-link {{ request()->is('employee/leaves*') ? 'active' : '' }}">
        <i class="nav-icon fas fa-calendar-check"></i>
        <p>
            Cuti
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="{{ route('employee.leaves.create') }}" 
               class="nav-link {{ request()->routeIs('employee.leaves.create') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Ajukan Cuti</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('employee.leaves.index') }}" 
               class="nav-link {{ request()->routeIs('employee.leaves.index') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Cuti</p>
            </a>
        </li>
    </ul>
</li>

{{-- LEMBUR --}}
<li class="nav-item has-treeview {{ request()->is('employee/expenses*') ? 'menu-open' : '' }}">
    <a href="#" class="nav-link {{ request()->is('employee/expenses*') ? 'active' : '' }}">
        <i class="nav-icon fas fa-stopwatch"></i>
        <p>
            Lembur
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="{{ route('employee.expenses.create') }}" 
               class="nav-link {{ request()->routeIs('employee.expenses.create') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Klaim Lembur</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('employee.expenses.index') }}" 
               class="nav-link {{ request()->routeIs('employee.expenses.index') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Lembur</p>
            </a>
        </li>
    </ul>
</li>

{{-- REPORT --}}
<li class="nav-item has-treeview {{ request()->is('employee/self*') ? 'menu-open' : '' }}">
    <a href="#" class="nav-link {{ request()->is('employee/self*') ? 'active' : '' }}">
        <i class="nav-icon fas fa-file-invoice-dollar"></i>
        <p>
            Report
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="{{ route('employee.self.salary_slip') }}" 
               class="nav-link {{ request()->routeIs('employee.self.salary_slip') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Slip Gaji</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('employee.self.holidays') }}" 
               class="nav-link {{ request()->routeIs('employee.self.holidays') ? 'active' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>Daftar Hari Libur</p>
            </a>
        </li>
    </ul>
</li>

{{-- PROFIL SAYA --}}
<li class="nav-item">
    <a href="{{ route('employee.profile') }}" class="nav-link {{ request()->routeIs('employee.profile') ? 'active' : '' }}">
        <i class="nav-icon fas fa-user"></i>
        <p>Profil Saya</p>
    </a>
</li>

{{-- LOGOUT --}}
<li class="nav-item">
    <a href="{{ route('logout') }}" 
       class="nav-link"
       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="nav-icon fas fa-sign-out-alt text-danger"></i>
        <p>Logout</p>
    </a>
    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
        @csrf
    </form>
</li>
