<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    <!-- Left navbar -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li>
    </ul>

    <!-- Right navbar -->
    <ul class="navbar-nav ml-auto">

        <!-- User dropdown -->
        <li class="nav-item dropdown user user-menu">

            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">

                @if (optional(Auth::user()->employee)->photo)
                    <img src="{{ asset('storage/employee_photos/' . Auth::user()->employee->photo) }}"
                         class="user-image img-circle elevation-2" alt="User Image"
                         style="object-fit: cover;">
                @else
                    <img src="{{ asset('dist/img/firyanul.png') }}"
                         class="user-image img-circle elevation-2" alt="User Image"
                         style="object-fit: cover;">
                @endif

                <span class="hidden-xs">{{ Auth::user()->name }}</span>

            </a>

            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">

                <!-- User info -->
                <li class="user-header bg-primary">

                    @if (optional(Auth::user()->employee)->photo)
                        <img src="{{ asset('storage/employee_photos/' . Auth::user()->employee->photo) }}"
                             class="img-circle elevation-2" alt="User Image"
                             style="object-fit: cover;">
                    @else
                        <img src="{{ asset('dist/img/firyanul.png') }}"
                             class="img-circle elevation-2" alt="User Image"
                             style="object-fit: cover;">
                    @endif

                    <p>
                        {{ Auth::user()->name }}
                        @if(optional(Auth::user()->employee)->desg)
                            - {{ Auth::user()->employee->desg }}
                        @endif
                        <small>
                            Terdaftar sejak
                            {{ optional(Auth::user()->employee->join_date)->format('M. Y') }}
                        </small>
                    </p>

                </li>

                <!-- Footer -->
                <li class="user-footer">
                    <div class="pull-left">
                        <a href="{{ route('admin.profile') }}" class="btn btn-default btn-flat">Profil</a>
                    </div>

                    <div class="pull-right">
                        <a href="{{ route('logout') }}"
                           class="btn btn-default btn-flat"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Keluar
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </li>

            </ul>
        </li>

        <!-- Control sidebar -->
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
            </a>
        </li>

    </ul>

</nav>
