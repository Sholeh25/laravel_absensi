@extends('layouts.app')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard Admin</h1>
            </div><div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">Halaman Utama</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div></div></div></div>
<section class="content">
    <div class="container-fluid">
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-lg border-0 rounded-lg">
                    <div class="card-body text-center p-5">
                        
                        @if(optional(Auth::user()->employee)->photo)
                            <img src="{{ asset('storage/employee_photos/' . Auth::user()->employee->photo) }}" alt="User Photo" class="mb-4 d-block mx-auto img-circle elevation-2" style="width: 100px; height: 100px; object-fit: cover;">
                        @else
                            <img src="{{ asset('dist/img/firyanul.png') }}" alt="Default Logo" class="mb-4 d-block mx-auto img-circle elevation-2" style="width: 100px; height: 100px; object-fit: cover;">
                        @endif
                        
                        <h1 class="display-5 text-primary font-weight-bold mb-3">
                            Selamat Datang, {{ Auth::user()->name }}!
                        </h1>
                        <p class="lead mb-4" style="color: #555;">
                            Anda telah berhasil masuk ke <strong>Panel Admin Website Absensi</strong>.
                            <br>
                            Sistem ini siap digunakan untuk mendukung operasional <strong>PT Foresthree Waralaba Indonesia</strong>.
                        </p>
                        
                        <hr>

                        <div class="mt-4">
                            <p>Menu Cepat:</p>
                            <a href="{{ route('admin.employees.index') }}" class="btn btn-outline-primary mx-1"><i class="fas fa-users"></i> Karyawan</a>
                            <a href="{{ route('admin.employees.attendance') }}" class="btn btn-outline-success mx-1"><i class="fas fa-clock"></i> Absensi</a>
                            <a href="{{ route('admin.penggajian.index') }}" class="btn btn-outline-info mx-1"><i class="fas fa-money-bill-wave"></i> Penggajian</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div></section>
@endsection