@extends('layouts.app')        

@section('content')
    <div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Absensi</h1>
            </div>
                        <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="{{ route('admin.index') }}">Dashboard Admin</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Absensi
                    </li>
                </ol>
            </div>
                    </div>
            </div>
    </div>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 mx-auto">
                <div class="card card-primary">
                    <div class="card-header">
                        <h5 class="text-center">Tanggal Absensi</h5>
                    </div>
                    <form action="{{ route('admin.employees.attendance') }}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="input-group mx-auto" style="width:70%">
                            <span class="input-group-text"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                            <input type="text" name="date" id="date" class="form-control text-center" >
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <button class="btn btn-flat btn-primary" type="submit">Submit</button>
                    </div>
                    </form>
                </div>
    _       </div>
        </div>
        <div class="row">
        {{-- Diperlebar agar muat --}}
            <div class="col-lg-12 mx-auto"> 
                @include('messages.alerts')
                <div class="card card-primary">
                    <div class="card-header">
                        <div class="card-title text-center">
                            @if ($date)
                            Absensi Karyawan berdasarkan rentang tanggal {{ $date }}                                
                            @else
                            Absensi Karyawan Hari ini
                            @endif
                        </div>
                        
                    </div>
                    <div class="card-body">
                        @if ($employees->count())
                        {{-- REVISI: Menggunakan table-responsive agar bisa di-scroll di HP --}}
                        <table class="table table-bordered table-hover table-responsive" id="dataTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                <th>Status Hadir</th>
                                <th>Jam Masuk</th>
                                    <th>Lokasi Masuk</th>
                                <th>Koordinat Masuk</th> {{-- BARU --}}
                                <th>Jam Keluar</th>
                                <th>Lokasi Keluar</th>
                                <th>Koordinat Keluar</th> {{-- BARU --}}
                                    <th>Jabatan</th>
                                    <th>Aksi</th>
s                          </tr>
                            </thead>
                            <tbody>
                                @foreach ($employees as $index => $employee)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $employee->first_name.' '.$employee->last_name }}</td>
                                    
                                {{-- REVISI: Logika di-rapihkan --}}
                                @if($employee->attendanceToday)
                                    {{-- Status Hadir --}}
                                        @if($employee->attendanceToday->time<=9 && $employee->attendanceToday->time>=7)
              _                       <td><h6 class="text-center"><span class="badge badge-pill badge-success">Hadir Tepat Waktu</span></h6></td>
                                        @elseif ($employee->attendanceToday->time>9 && $employee->attendanceToday->time<=17)
                                            <td><h6 class="text-center"><span class="badge badge-pill badge-warning">Hadir Terlambat</span></h6></td>
                                        @else
                                            <td><h6 class="text-center"><span class="badge badge-pill badge-danger">Absensi Tidak Valid</span></h6></td>
                                        @endif

                                    {{-- Jam Masuk --}}
                                    <td>{{ $employee->attendanceToday->created_at->format('H:i:s') }}</td>
                                    {{-- Lokasi Masuk --}}
                                    <td>{{ $employee->attendanceToday->entry_location}}</td>
                                    {{-- Koordinat Masuk (BARU) --}}
                                    <td>{{ $employee->attendanceToday->entry_latitude ?? '-' }}, {{ $employee->attendanceToday->entry_longitude ?? '-' }}</td>

                                    {{-- Jam Keluar & Lokasi Keluar & Koordinat Keluar --}}
                                        @if(!empty($employee->attendanceToday->exit_location))
                                            <td>{{ $employee->attendanceToday->updated_at->format('H:i:s') }}</td>
                                        <td>{{ $employee->attendanceToday->exit_location}}</td>
                                        <td>{{ $employee->attendanceToday->exit_latitude ?? '-' }}, {{ $employee->attendanceToday->exit_longitude ?? '-' }}</td>
                                        @else
                                        <td><h6 class="text-center"><span class="badge badge-pill badge-danger">Belum Pulang</span></h6></td>
                                            <td><h6 class="text-center"><span class="badge badge-pill badge-danger">-</span></h6></td>
                                        <td><h6 class="text-center"><span class="badge badge-pill badge-danger">-</span></h6></td>
                                        @endif

                                    <td>{{ $employee->desg }}</td>
                                    <td>
                                        @if($employee->attendanceToday)
                                            <button 
                                            class="btn btn-flat btn-danger btn-sm"
                                            data-toggle="modal"
                                            data-target="#deleteModalCenter{{ $employee->attendanceToday->id }}"
                                            >Hapus</button>
                                        @else
                                            Aksi Tidak Tersedia
                                        @endif
                                    </td>
                                @else
                                        {{-- Jika Belum Ada Riwayat --}}
                                        {{-- REVISI: Colspan disesuaikan menjadi 10 --}}
                                        <td colspan="10" class="text-center"><h6 class="text-center"><span class="badge badge-pill badge-danger">Belum Ada Riwayat Hari Ini</span></h6></td>
Ind                            @endif
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        
                        {{-- Modal Deletion --}}
                        {{-- REVISI: Menggunakan @foreach yang lebih aman --}}
                        @foreach ($employees as $employee)
                                @if($employee->attendanceToday)
                    _           <div class="modal fade" id="deleteModalCenter{{ $employee->attendanceToday->id }}" tabindex="-1" role="dialog" aria-labelledby="deleteModalCenterTitle{{ $employee->attendanceToday->id }}" aria-hidden="true">
                                    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                                        <div class="modal-content">
A                                      <div class="card card-danger">
                                                <div class="card-header">
                                                    <h5 style="text-align: center !important">Yakin ingin dihapus?</h5>
A                                            </div>
                                                <div class="card-body text-center d-flex" style="justify-content: center">
Note:                            _             
                                                    <button type="button" class="btn flat btn-secondary" data-dismiss="modal">Tidak</button>
                                                    
                                                    <form 
key                _                         action="{{ route('admin.employees.attendance.delete', $employee->attendanceToday->id) }}"
                                                    method="POST"
A                                              >
                                                    @csrf
                                                    @method('DELETE')
                                                        <button type="submit" class="btn flat btn-danger ml-1">Ya</button>
Lain                                            </form>
                                                </div>
                                                {{-- Menghapus footer modal yang tidak perlu --}}
A                                        </div>
                                        </div>
Note:                                </div>
                                </div>
                                s                          @endif
                        @endforeach
                        @else
                    t   <div class="alert alert-info text-center" style="width:50%; margin: 0 auto">
                            <h4>Belum Ada Riwayat</h4>
                        </div>
                        @endif
E                       
                    </div>
                </div>
                                
            </div>
        </div>
    </div>
  I </section>
  g @endsection
@section('extra-js')

<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            responsive:true,
            autoWidth: false,
Do            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['copy','excel', 'csv', 'pdf'],
              _ }
            ]
        });
        $('#date').daterangepicker({
Date          "singleDatePicker": true,
            "showDropdowns": true,
            "locale": {
                "format": "DD-MM-YYYY"
            }
        });
    });
</script>
@endsection