            @include('messages.alerts')

            <form action="{{ route('register.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="card-body">
                    <fieldset>
                        <!-- Nama Awal -->
                        <div class="form-group mb-3">
                            <label for="first_name">Nama Awal</label>
                            <input type="text" name="first_name" id="first_name"
                                value="{{ old('first_name') }}"
                                class="form-control @error('first_name') is-invalid @enderror">
                            @error('first_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Nama Akhir -->
                        <div class="form-group mb-3">
                            <label for="last_name">Nama Akhir</label>
                            <input type="text" name="last_name" id="last_name"
                                value="{{ old('last_name') }}"
                                class="form-control @error('last_name') is-invalid @enderror">
                            @error('last_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Email -->
                        <div class="form-group mb-3">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email"
                                value="{{ old('email') }}"
                                class="form-control @error('email') is-invalid @enderror">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Tanggal Lahir -->
                        <div class="form-group mb-3">
                            <label for="dob">Tanggal Lahir</label>
                            <input type="text" name="dob" id="dob"
                                value="{{ old('dob') }}" autocomplete="off"
                                class="form-control @error('dob') is-invalid @enderror">
                            @error('dob')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Jenis Kelamin -->
                        <div class="form-group mb-3">
                            <label for="sex">Jenis Kelamin</label>
                            <select name="sex" id="sex"
                                class="form-control @error('sex') is-invalid @enderror">
                                <option hidden disabled selected value> -- Pilih Opsi -- </option>
                                <option value="Male" @selected(old('sex') == 'Male')>Laki-Laki</option>
                                <option value="Female" @selected(old('sex') == 'Female')>Perempuan</option>
                            </select>
                            @error('sex')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Tanggal Bergabung -->
                        <div class="form-group mb-3">
                            <label for="join_date">Tanggal Bergabung</label>
                            <input type="text" name="join_date" id="join_date"
                                value="{{ old('join_date') }}" autocomplete="off"
                                class="form-control @error('join_date') is-invalid @enderror">
                            @error('join_date')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Jabatan dan Department -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="desg">Jabatan</label>
                                <select name="desg" id="desg"
                                    class="form-control @error('desg') is-invalid @enderror">
                                    <option hidden disabled selected value> -- Pilih Opsi -- </option>
                                    <option value="Manajer" @selected(old('desg') == 'Manajer')>Manajer</option>
                                    <option value="Asisten Manajer" @selected(old('desg') == 'Asisten Manajer')>Asisten Manajer</option>
                                    <option value="Kepala Divisi" @selected(old('desg') == 'Kepala Divisi')>Kepala Divisi</option>
                                    <option value="Staff" @selected(old('desg') == 'Staff')>Staff</option>
                                </select>
                                @error('desg')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6">
                                <label for="department_id">Department</label>
                                <select name="department_id" id="department_id"
                                    class="form-control @error('department_id') is-invalid @enderror">
                                    <option hidden disabled selected value> -- Pilih Opsi -- </option>
                                    @isset($departments)
                                        @foreach ($departments as $department)
                                            <option value="{{ $department->id }}"
                                                @selected(old('department_id') == $department->id)>
                                                {{ $department->name }}
                                            </option>
                                        @endforeach
                                    @endisset
                                </select>
                                @error('department_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <!-- Gaji -->
                        <div class="form-group mb-3">
                            <label for="salary">Gaji</label>
                            <input type="number" name="salary" id="salary"
                                value="{{ old('salary') }}"
                                class="form-control @error('salary') is-invalid @enderror">
                            @error('salary')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Foto -->
                        <div class="form-group mb-3">
                            <label for="photo">Foto</label>
                            <input type="file" name="photo" id="photo"
                                class="form-control @error('photo') is-invalid @enderror">
                            @error('photo')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Password -->
                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password"
                                class="form-control @error('password') is-invalid @enderror">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Konfirmasi Password -->
                        <div class="form-group mb-3">
                            <label for="password_confirmation">Konfirmasi Password</label>
                            <input type="password" name="password_confirmation"
                                id="password_confirmation" class="form-control">
                        </div>
                    </fieldset>
                </div>

                <div class="card-footer text-center">
                    <button type="submit" class="btn btn-primary btn-flat me-2" style="width: 40%; font-size:1.2rem;">Tambah</button>
                    <a href="{{ route('login') }}" class="btn btn-warning btn-flat" style="width: 40%; font-size:1.2rem;">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
